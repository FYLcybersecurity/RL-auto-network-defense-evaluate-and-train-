

#sub_agents = {'B_line_trained':'/log_dir/b_line_trained/PPO_CybORGAgent_e81fb_00000_0_2022-01-29_11-23-39/checkpoint_002500/checkpoint-2500',
#              'RedMeander_trained':'/log_dir/meander_trained/PPO_CybORGAgent_3c456_00000_0_2022-01-27_20-39-34/checkpoint_001882/checkpoint-1882'
#              }


sub_agents = {'B_line_trained':'/log_dir/b_line_trained/PPO_CybORGAgent_e81fb_00000_0_2022-01-29_11-23-39/checkpoint_002500/checkpoint-2500',
              'RedMeander_trained':'/log_dir/meander_trained/PPO_CybORGAgent_3c456_00000_0_2022-01-27_20-39-34/checkpoint_001882/checkpoint-1882'
              }